import java.util.Scanner;

public class Login {
	public static void main(String [] args) {
		//For register
		System.out.println("Please choose your Username: ");
		Scanner scan = new Scanner(System.in);
		String username = scan.nextLine();
		//Then we are going to connect to the database and use sql to see is this name already being used
		//If not we can proceed to next step;
		String password = scan.nextLine();
		//Now we have the information we need, and we can insert information to database
		String sql = "INSERT " + username +"," + password + " INTO " + " Login;";

/*******************************************************************************************************************/
		
		//For login
		System.out.println("Please enter you username: ");
		String user = scan.nextLine();
		String pass = scan.nextLine();
		//Then we are going to use sql to search for its password, see whether the password match the password in database
		String sql2 = "SELECT " + password + " FROM Login WHERE username = " + user +";";
		if(pass == password) {
			//Authentication passed
		}else {
			//Your password is wrong
		}
	}
}
