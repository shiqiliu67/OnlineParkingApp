import java.util.Scanner;
public class Lots {
	public static void main(String [] args) {
		System.out.println("Please select the parking lot");
		//Will display the location of lots
		int [] array = new int[200];
		System.out.println("Please select the parking space(From 0 - 199) from below: ");
		for(int i=0;i<200;i++) {
			if(array[i] == 0) {
				System.out.println(i);
			}
		}
		Scanner scan = new Scanner(System.in);
		int select = scan.nextInt();
		array[select] = 1;
		System.out.println("Enter you name: ");
		String name = scan.nextLine();
		System.out.println("Enter the time interval: ");
		String interval = scan.nextLine();
		//Send to database
		//Enter the information into database
	}
}
