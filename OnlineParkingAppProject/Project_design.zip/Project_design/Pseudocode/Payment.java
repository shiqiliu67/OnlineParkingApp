import java.util.Scanner;
public class Payment {
	public static void main(String [] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Your card number: ");
		String cnumber = scan.nextLine();
		System.out.println("expiration: ");
		String exp = scan.nextLine();
		System.out.println("cvv: ");
		String cvv = scan.nextLine();
		//Insert into database
	}
}
